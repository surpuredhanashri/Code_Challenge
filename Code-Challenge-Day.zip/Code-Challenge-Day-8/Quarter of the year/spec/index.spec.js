describe("Test Case 1", function() {
    it("should determine the quarterOf", function() {
        expect(quarterOf(3)).toEqual(1);;
      });
});
describe("Test Case 2", function() {
  it("should determine the quarterOf", function() {
      expect(quarterOf(8)).toEqual(3);;
    });
});
describe("Test Case 3", function() {
  it("should determine the quarterOf", function() {
      expect(quarterOf(11)).toEqual(4);;
    });
});
describe("Test Case 4", function() {
  it("should determine the quarterOf", function() {
      expect(quarterOf(7)).toEqual(3);;
    });
});
describe("Test Case 5", function() {
  it("should determine the quarterOf", function() {
      expect(quarterOf(1)).toEqual(1);;
    });
});


