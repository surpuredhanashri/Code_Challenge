// Ajay, Binoy and Chandru were very close friends at school. 
// They were very good in Mathematics and they were the pet students of Emily Mam. 
// Their gang was known as 3-idiots. Ajay, Binoy and Chandru live in the same locality.

// A new student Dinesh joins their class and he wanted to be friends with them. 
// He asked Binoy about his house address. Binoy wanted to test Dinesh's mathematical skills. 
// Binoy told Dinesh that his house is at the midpoint of the line joining Ajay's house and Chandru's house. 
// Dinesh was puzzled. Can you help Dinesh out?

//Given the coordinates of the 2 end points of a line (x1,y1) and (x2,y2), write a  
// function to find the midpoint of the line.

// Write the function to return the midpoint M1 of the line.
function find_MidPoint_M1(X1,Y1,X2,Y2){
   M1 = ((X1+X2)/2);
    return M1;
    
}

// Write the function to return the midpoint M2 of the line.
function find_MidPoint_M2(X1,Y1,X2,Y2){
    M2 = ((Y1+Y2)/2);
    return M2;
}


//Use SpecRunner to check the Test Cases.

 